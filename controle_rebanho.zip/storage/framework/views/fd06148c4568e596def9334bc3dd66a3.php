

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Listagem de Vacas</h2>
    <a href="<?php echo e(route('vacas.create')); ?>" class="btn btn-primary">Nova Vaca</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Número de Identificação</th>
                <th>Nome</th>
                <th>Data de Nascimento</th>
                <th>Raça</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vacas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vaca->id); ?></td>
                <td><?php echo e($vaca->nro_identificacao); ?></td>
                <td><?php echo e($vaca->nome); ?></td>
                <td><?php echo e($vaca->data_nascimento); ?></td>
                <td><?php echo e($vaca->raca); ?></td>
                <td>
                    <a href="#" class="btn btn-info" data-toggle="modal" data-target="#detalhesModal<?php echo e($vaca->id); ?>">Detalhes</a>
                    <a href="<?php echo e(route('vacas.edit', $vaca->id)); ?>" class="btn btn-primary">Editar</a>
                    <form action="<?php echo e(route('vacas.destroy', $vaca->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Excluir</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- Modal para Detalhes da Vaca -->
<?php $__currentLoopData = $vacas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detalhesModal<?php echo e($vaca->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detalhes da Vaca</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><strong>Nome:</strong> <?php echo e($vaca->nome); ?></p>
                <p><strong>Nº. Identificação:</strong> <?php echo e($vaca->nro_identificacao); ?></p>
                <p><strong>Data de Nascimento:</strong> <?php echo e($vaca->data_nascimento); ?></p>
                <p><strong>Raça:</strong> <?php echo e($vaca->raca); ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\guipr\controle_rebanho\resources\views/vacas/index.blade.php ENDPATH**/ ?>