// import './bootstrap';
// import { Calendar } from '@fullcalendar/core';
// import dayGridPlugin from '@fullcalendar/daygrid';
// import interactionPlugin from '@fullcalendar/interaction';

// document.addEventListener('DOMContentLoaded', function () {
//     var calendarEl = document.getElementById('calendar'); // Substitua 'calendar' pelo ID do elemento onde você deseja exibir o calendário.

//     var calendar = new Calendar(calendarEl, {
//         plugins: [dayGridPlugin, interactionPlugin],
//         initialView: 'dayGridMonth', // Você pode escolher a visualização inicial do calendário
//         // Adicione seus eventos ou eventos dinâmicos aqui
//         events: [
//             // Exemplo de evento
//             {
//                 title: 'Evento 1',
//                 start: '2023-09-15',
//             },
//             // Adicione mais eventos conforme necessário
//         ],
//     });

//     calendar.render();
// });
